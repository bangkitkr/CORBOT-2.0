import nltk
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
import json
import pickle

import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import SGD
import random

words=[]
classes = []
documents = []
ignore_words = ['?', '!', 'apa', 'itu', 'apakah', 'bagaimana', 'adalah', 'saja', 'yang', 'aku', 'saya', 'anda', 'darimana', 'dari', 'mana', 'kamu', 'dia']
data_file = open('model/content.json').read()
intents = json.loads(data_file)


for intent in intents['intents']:
    for pattern in intent['input']:

        #tokenize setiap kata
        w = nltk.word_tokenize(pattern)
        words.extend(w)
        #menambahkan dokumen dalam corpus
        documents.append((w, intent['tag']))

        # tambahkan ke dalam classes list
        if intent['tag'] not in classes:
            classes.append(intent['tag'])

# lemmatize, lower setiap kata dan hapus duplikat
words = [lemmatizer.lemmatize(w.lower()) for w in words if w not in ignore_words]
words = sorted(list(set(words)))
# mengurutkan classes
classes = sorted(list(set(classes)))
# documents = kombinasi antara patterns and intents
print (len(documents), "documents")
# classes = intents
print (len(classes), "classes", classes)
# words = semua words, vocabulary
print (len(words), "unique lemmatized words", words)


pickle.dump(words,open('model/texts.pkl','wb'))
pickle.dump(classes,open('model/labels.pkl','wb'))

# membuat data training
training = []
# membuat array kosong untuk output
output_empty = [0] * len(classes)
# set training, bag of words untuk setiap kalimat
for doc in documents:
    # inisialisasi bag of words
    bag = []
    # daftar kata-kata yang diberik tokenized untuk pattern
    pattern_words = doc[0]
    # lemmatize setiap kata, membuat kata dasar, dalam upaya untuk mewakili kata-kata terkait
    pattern_words = [lemmatizer.lemmatize(word.lower()) for word in pattern_words]
    # membuat array bag of words dengan 1, jika kata ditemuka cocok dalam pattern saat ini
    for w in words:
        bag.append(1) if w in pattern_words else bag.append(0)
    
    # output is a '0' for each tag and '1' for current tag (for each pattern)
    output_row = list(output_empty)
    output_row[classes.index(doc[1])] = 1
    
    training.append([bag, output_row])
# shuffle our features and turn into np.array
random.shuffle(training)
training = np.array(training)
# create train and test lists. X - patterns, Y - intents
train_x = list(training[:,0])
train_y = list(training[:,1])
print("Training data dibuat")


# Create model - 3 layers. First layer 128 neurons, second layer 64 neurons and 3rd output layer contains number of neurons
# equal to number of intents to predict output intent with softmax
model = Sequential()
model.add(Dense(128, input_shape=(len(train_x[0]),), activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(64, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(len(train_y[0]), activation='softmax'))

# Compile model. Stochastic gradient descent with Nesterov accelerated gradient gives good results for this model
sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])

#fitting and saving the model 
hist = model.fit(np.array(train_x), np.array(train_y), epochs=1000, batch_size=5, verbose=1)
model.save('model/model.h5', hist)

print("model dibuat")
scores = model.evaluate(np.array(train_x), np.array(train_y), verbose=0)
print("Skor %s: %.2f%%" % (model.metrics_names[1], scores[1]*100))